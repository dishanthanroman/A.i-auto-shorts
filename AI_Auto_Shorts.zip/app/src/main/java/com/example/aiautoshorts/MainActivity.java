package com.example.aiautoshorts;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.text.InputType;

public class MainActivity extends Activity {
    private EditText youtubeUrl, driveUrl;
    private Spinner duration;
    private CheckBox captions, vertical, bestMoments;
    private TextView status;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ScrollView scroll = new ScrollView(this);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(28, 28, 28, 28);
        page.setBackgroundColor(Color.rgb(17, 24, 39));
        scroll.addView(page);

        TextView title = new TextView(this);
        title.setText("AI AUTO SHORTS");
        title.setTextColor(Color.WHITE); title.setTextSize(26); title.setGravity(Gravity.CENTER);
        page.addView(title);
        TextView subtitle = new TextView(this);
        subtitle.setText("Turn long videos into short clips");
        subtitle.setTextColor(Color.LTGRAY); subtitle.setTextSize(15);
        subtitle.setGravity(Gravity.CENTER); page.addView(subtitle);

        youtubeUrl = input("YouTube video URL (access must be permitted)");
        page.addView(youtubeUrl);
        driveUrl = input("Google Drive share link");
        page.addView(driveUrl);

        TextView d = label("Clip length"); page.addView(d);
        duration = new Spinner(this);
        String[] options = {"15 seconds", "30 seconds", "60 seconds"};
        duration.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, options));
        page.addView(duration);

        captions = check("Generate captions"); captions.setChecked(true); page.addView(captions);
        vertical = check("Vertical 9:16 format"); vertical.setChecked(true); page.addView(vertical);
        bestMoments = check("Find best moments"); bestMoments.setChecked(true); page.addView(bestMoments);

        Button create = new Button(this); create.setText("CREATE SHORTS"); page.addView(create);
        status = new TextView(this); status.setTextColor(Color.WHITE); status.setTextSize(14);
        status.setPadding(0, 20, 0, 0); page.addView(status);

        TextView note = new TextView(this);
        note.setTextColor(Color.LTGRAY); note.setTextSize(12);
        note.setText("\nVersion 1 interface. AI processing requires a configured backend. YouTube links cannot always be downloaded; use content you own or are authorized to process. Drive files must be accessible to the processing service.");
        page.addView(note);

        create.setOnClickListener(v -> {
            String yt = youtubeUrl.getText().toString().trim();
            String gd = driveUrl.getText().toString().trim();
            if (yt.isEmpty() && gd.isEmpty()) {
                status.setText("Paste a YouTube URL or Google Drive link first.");
                return;
            }
            if (!yt.isEmpty() && !yt.startsWith("https://") && !yt.startsWith("http://")) {
                status.setText("Please enter a valid YouTube URL beginning with https://");
                return;
            }
            if (!gd.isEmpty() && !gd.startsWith("https://") && !gd.startsWith("http://")) {
                status.setText("Please enter a valid Google Drive URL beginning with https://");
                return;
            }
            status.setText("Request prepared (" + duration.getSelectedItem().toString() + ").\n\nThis starter APK does not yet process videos. Connect an authorized video-processing backend to enable AI analysis, clipping, captions, and export.");
        });

        setContentView(scroll);
    }

    private EditText input(String hint) {
        EditText e = new EditText(this);
        e.setHint(hint); e.setTextColor(Color.WHITE); e.setHintTextColor(Color.GRAY);
        e.setSingleLine(false); e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        e.setPadding(14, 10, 14, 10);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 18, 0, 8); e.setLayoutParams(lp);
        return e;
    }
    private TextView label(String text) {
        TextView t = new TextView(this); t.setText(text); t.setTextColor(Color.WHITE);
        t.setTextSize(16); t.setPadding(0, 14, 0, 6); return t;
    }
    private CheckBox check(String text) {
        CheckBox c = new CheckBox(this); c.setText(text); c.setTextColor(Color.WHITE); return c;
    }
}
